public class Main{
    public static void main(String[] args){

        Book book1 = new Book();
        Book book2 =book1;
        IO.println(book1.getTitle()+" "+book1.getAuthor()+" "+book1.getYear());
        IO.println(book1.getTitle()+" "+book2.getAuthor()+" "+book2.getYear());

        book2.setTitle("Harry poter");
        book2.setAuthor("J. K. Rowling");
        book2.setYear(2018);

        IO.println(book1.getTitle()+" "+book1.getAuthor()+" "+book1.getYear());
        IO.println(book1.getTitle()+" "+book2.getAuthor()+" "+book2.getYear());
        //zmianny wpłyneły na dwie zmienne typu Book, ponieważ
        //zmiena book1 i book2 to zmienne odnośnikowe które nie
        //zapisuja w sobie wartości tylko adres w pamieci.
        //tak my przypisalismy book1 do book2 - wiec oba adresy
        //wskazuja na te same miejsce w pamieci (pola w Klasie Book)
        //i tak naprawde operowalismy na polach classy Book
        //wiec wyswietlajac drugi raz po zmianie book1 i book2
        // widzimmy 2 razy te same wartosci.
    }


}
