public class Book {
    private String title;
    private String author;
    private int year;

    public Book(){
        this.title = "Martwe dusze";
        this.author = "Mikolaj Gogol";
        this.year = 1842;
    }
    public String getTitle() {
        return title;
    }
    public String getAuthor() {
        return author;
    }
    public int getYear() {
        return year;
    }
    public void setTitle(String title1){
        this.title =title1;
    }
    public void setAuthor(String author1){
        this.author =author1;
    }
    public void setYear(int year1){
        this.year =year1
        ;
    }
}
